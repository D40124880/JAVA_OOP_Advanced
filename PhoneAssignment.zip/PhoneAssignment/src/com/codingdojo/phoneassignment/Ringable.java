package com.codingdojo.phoneassignment;

public interface Ringable {
	String ring();
	String unlock();
}
